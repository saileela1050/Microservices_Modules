package com.example.employeemanagement.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class DepartmentResponse {
    private Long id;
    private String name;
    private List<EmployeeSummaryResponse> employees;

    public DepartmentResponse() {
    }

    public DepartmentResponse(Long id, String name, List<EmployeeSummaryResponse> employees) {
        this.id = id;
        this.name = name;
        this.employees = employees;
    }
}